# TurboCode-matlab
Matlab implementation of Turbo code: https://en.wikipedia.org/wiki/Turbo_code

Run
- turbo_sim.m
